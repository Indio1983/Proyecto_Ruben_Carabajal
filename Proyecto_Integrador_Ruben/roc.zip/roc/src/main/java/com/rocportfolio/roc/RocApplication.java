package com.rocportfolio.roc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RocApplication {

	public static void main(String[] args) {
		SpringApplication.run(RocApplication.class, args);
	}

}
