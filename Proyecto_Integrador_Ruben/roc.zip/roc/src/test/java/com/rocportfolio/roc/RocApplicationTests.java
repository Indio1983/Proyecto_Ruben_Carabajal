package com.rocportfolio.roc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RocApplicationTests {

	@Test
	void contextLoads() {
	}

}
